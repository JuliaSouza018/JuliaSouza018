document.addEventListener('deviceready', async function () {

}, false);

