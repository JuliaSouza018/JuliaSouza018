import {banco, verificador} from "./firebase/configuracao.js";
import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification, sendPasswordResetEmail}
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

document.addEventListener('deviceready', async function () {
    let usuario;
  
    const verificaUsuario = async () => {
        return new Promise((resolve, reject) => {
          onAuthStateChanged(verificador, (user) => {
            if (user) {
              console.log("Usuário logado:", user.email);
              usuario = user.uid;
              resolve(usuario);
            } else {
              console.log("Nenhum usuário logado");
              window.location.href = "login.html";
              reject("Usuário não logado");
            }
          });
        });
    };

    await verificaUsuario();
    const resultado2 = await getDoc(doc(banco, "usuarios", usuario, "perfil", "dados"));

    const moedaQuantia = document.querySelector('.coin-number');
    moedaQuantia.textContent = resultado2.data().moedas_usu

}, false);

