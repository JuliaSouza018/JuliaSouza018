
      // Abrir Pop-up
      function openBooksPopup() {
        document.getElementById('books-popup').style.display = 'flex';
      }

      // Fechar Pop-up ao clicar fora
      function closeBooksPopup(event) {
        if (event.target.id === 'books-popup') {
          document.getElementById('books-popup').style.display = 'none';
        }
      }
    