const slider = document.querySelector('.slider');
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');

let currentIndex = 0; // Índice do slide atual
let startX = 0; // Posição inicial do toque
let endX = 0;   // Posição final do toque

// Atualiza a posição do slider para o slide atual
function updateSliderPosition() {
  slider.style.transform = `translateX(-${currentIndex * 100}%)`;
  updateDots();
}

// Atualiza os "dots" de navegação para refletir o slide atual
function updateDots() {
  dots.forEach((dot, index) => {
    dot.classList.toggle('active', index === currentIndex);
  });
}

// Move para o próximo slide
function nextSlide() {
  if (currentIndex < slides.length - 1) {
    currentIndex++;
    updateSliderPosition();
  }
}

// Move para o slide anterior
function prevSlide() {
  if (currentIndex > 0) {
    currentIndex--;
    updateSliderPosition();
  }
}

// Detecta o início do toque
slider.addEventListener('touchstart', (e) => {
  startX = e.touches[0].clientX;
});

// Detecta o fim do toque e verifica a direção
slider.addEventListener('touchend', (e) => {
  endX = e.changedTouches[0].clientX;
  const deltaX = endX - startX;

  if (deltaX > 50) {
    // Deslizou para a direita
    prevSlide();
  } else if (deltaX < -50) {
    // Deslizou para a esquerda
    nextSlide();
  }
});

// Adiciona eventos de clique aos "dots"
dots.forEach((dot, index) => {
  dot.addEventListener('click', () => {
    currentIndex = index;
    updateSliderPosition();
  });
});

// Inicializa o swiper
updateSliderPosition();
