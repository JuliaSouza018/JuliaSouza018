/*document.addEventListener('deviceready', async function () {


}); */
import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import {banco, verificador} from "./firebase/configuracao.js";
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
/* swipper da index*/

document.addEventListener('DOMContentLoaded', function () {
  const swiper = new Swiper('.swiper-container', {
    slidesPerView: 2.5,
    spaceBetween: 1,
    breakpoints: {
      768: { slidesPerView: 2 },
      1024: { slidesPerView: 3 },
    },
  });
});


document.addEventListener('deviceready', async function () {


let usuario;

const verificaUsuario = async () => {
  return new Promise((resolve, reject) => {
    onAuthStateChanged(verificador, (user) => {
      if (user) {
        usuario = user.uid;
        resolve(usuario);
      } else {
        alert("Nenhum usuário logado.");
        window.location.href = "login.html";
        reject("Usuário não logado");
      }
    });
  });
};

verificaUsuario();


const abrirObra = (obra, titulo, autor) => {
    localStorage.setItem("obraSelecionada", obra);
    localStorage.setItem("obraTitulo", titulo);
    window.location.href = "livro.html";
  };
  
  
  const criarObra = (livro) => {
    return `
    <div class="swiper-slide">
      <a href="" class="">
        <div class="card3 cor-link">
          <div class="card-image-container3">
            <img src="${livro.imagem}" alt="Imagem do Card" class="card-image3">
          </div>
          <div class="card-content3">
            <h3 class="card-title3">${livro.titulo}</h3>
            <p class="card-subtitle3">por ${livro.autor}</p>
          </div>
        </div>
      </a>
    </div>`;
    
  };
  
  
  const carregarObras = async (pesquisa, containerId, inicio) => {
    const container = document.getElementById(containerId);
    container.innerHTML = "<p>Carregando Livros...</p>";
  
    try {
      const obras = await buscaLivroTexto(pesquisa, inicio);
  
      if (obras.length > 0) {
        container.innerHTML = obras.map(criarObra).join("");
      } else {
        container.innerHTML = "<p>Nenhum livro encontrado.</p>";
      }
  
      container.querySelectorAll(".swiper-slide").forEach((botao, index) => {
        const isbn = obras[index].isbn13;
        const titulo = obras[index].titulo;
        
        botao.addEventListener("click", () => abrirObra(isbn, titulo));
      });
    } catch (e) {
      container.innerHTML = "<p>Erro ao carregar livros. Tente novamente mais tarde.</p>";
    }
  };
  
  
  await carregarObras("Ficção", "containerDestaque", 0);
  await carregarObras("Historinha", "containerInfantil", 0);
  await carregarObras('Romance', "containerRomance", 0);
  
  document.querySelectorAll('img').forEach(img => {
    if (img.src.startsWith('http://')) {
      img.src = img.src.replace("http://", "https://");
    }
  });}, false);


  /*


  */