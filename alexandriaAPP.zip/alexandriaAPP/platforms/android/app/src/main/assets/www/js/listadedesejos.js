import {banco, verificador} from "./firebase/configuracao.js";
import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import { getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import { onAuthStateChanged, getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification, sendPasswordResetEmail}
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

document.addEventListener('deviceready', async function () {
    let usuario;

    const verificaUsuario = async () => {
        return new Promise((resolve, reject) => {
          onAuthStateChanged(verificador, (user) => {
            if (user) {
              console.log("Usuário logado:", user.email);
              usuario = user.uid;
              resolve(usuario);
            } else {
              console.log("Nenhum usuário logado");
              window.location.href = "login.html";
              reject("Usuário não logado");
            }
          });
        });
    };
    
    const abrirObra = (obra, titulo, autor) => {
      localStorage.setItem("obraSelecionada", obra);
      localStorage.setItem("obraTitulo", titulo);
      window.location.href = "livro.html";
    };
    
    const abrirCadastro = (obra) => {
      window.location.href = `cadastro_livro.html?isbn=${obra}`;
    };
    
    const pesquisaLivros = async () => {
        const resultado = await getDocs(query(collection(doc(banco, "usuarios", usuario), "estante")));
        const livros = [];
        if (resultado.empty) {
          return '';
        } else {
          resultado.forEach( doc => {
            if (doc.data().categoria == 'A') {
              livros.push(doc.data().ISBN);
            }
          });
          return livros;
        }
    }
    
    
    const pesquisaObra = async (isbn) => {
      const container = document.getElementById("bookGrid");
    
      const obras = await buscaLivroISBN(isbn);
      
      container.innerHTML += `<div class="card3 cor-link" info-isbn="${obras.isbn13}" info-titulo="${obras.titulo}">
                <img src="${obras.imagem}" alt="Imagem do Card" class="card-image2">
                <div class="card-content2">
                  <h3 class="card-title2">${obras.titulo}</h3>
                  <p class="card-subtitle2">por ${obras.autor}</p>
                </div>
              </div>`
      
    }
    
    const carregaPag = async () => {
        await verificaUsuario();
    
        const container = document.getElementById("bookGrid");
        
        container.innerHTML = "<p>Carregando Livros...</p>";
    
    
        try {
            const livros = await pesquisaLivros();
    
            if (livros.length > 0) {
            container.innerHTML = "";
            await Promise.all(livros.map(livro => pesquisaObra(livro)));
    
            container.querySelectorAll(".card3").forEach((botao) => {
              const isbn = botao.getAttribute("info-isbn");
              const titulo = botao.getAttribute("info-titulo");
        
                botao.addEventListener("click", () => abrirObra(isbn, titulo));
            });
          } else {
            container.innerHTML = "Não há livros Lidos."
          }
    
        } catch (e) {
            console.log(e);
            container.innerHTML = "<p>Erro ao carregar livros. Tente novamente mais tarde.</p>";
        }
    }
    
    await carregaPag(); 
    
    document.querySelectorAll('img').forEach(img => {
        if (img.src.startsWith('http://')) {
          img.src = img.src.replace("http://", "https://");
        }
      });
}, false);