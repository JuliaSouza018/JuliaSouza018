import {buscaLivroISBN, buscaLivroISBN2, buscaLivroTexto} from "./firebase/configLivro.js";
import {banco, verificador} from "./firebase/configuracao.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDocs, where, query, updateDoc, serverTimestamp, deleteDoc }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import {onAuthStateChanged, getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification, sendPasswordResetEmail}
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";


document.addEventListener('deviceready', async function () {
  const txtTituloObra = document.getElementById("txtTituloObra");
  const txtAutorObra = document.getElementById("txtAutorObra");
  const txtDescObra = document.getElementById("txtDescObra");
  const txtEditObra = document.getElementById("txtEditObra");
  const txtPagsObra = document.getElementById("txtPagsObra");
  const txtI13Obra = document.getElementById("txtI13Obra");
  const imgObra = document.getElementById("main-image");
  const btnTrocar = document.getElementById("btnTrocar");
  const btnCadastrar = document.getElementById("btnCadastrar");
  const txtQuantia = document.getElementById("txtQuantia");
  let gIsbn = '';
  
  
  const botaoCoracao = document.getElementById("botao-coracao");
  const botaoLivro = document.getElementById("botao-livro");
  

let usuario;

const verificaUsuario = async () => {
  return new Promise((resolve, reject) => {
    onAuthStateChanged(verificador, (user) => {
      if (user) {
        usuario = user.uid;
        resolve(usuario);
      } else {
        alert("Nenhum usuário logado");
        window.location.href = "login.html";
        reject("Usuário não logado");
      }
    });
  });
};

verificaUsuario();

const carregaPag = async () => {
  const isbn = localStorage.getItem("obraSelecionada");
  const tituloOriginal = localStorage.getItem("obraTitulo");
  const obras = await buscaLivroISBN(isbn);
  const quantia = await getDocs(query(collection(banco, "Obra"), where("ISBN", "==", isbn), where("trocado", "==", false)));

  if (obras.titulo == tituloOriginal) {
      console.log(obras.titulo + " == " + tituloOriginal);
      txtTituloObra.innerHTML = obras.titulo;
      txtAutorObra.innerHTML = obras.autor;
      txtDescObra.innerHTML = obras.sinopse;
      txtEditObra.innerHTML = obras.editora;
      txtPagsObra.innerHTML = obras.paginas;
      txtI13Obra.innerHTML = obras.isbn13;
      imgObra.src = obras.imagem;
      gIsbn = obras.isbn13;
  } else if (obras.titulo != tituloOriginal){
      var obraNova = await buscaLivroISBN2(tituloOriginal);

      txtTituloObra.innerHTML = obraNova.titulo;
      txtAutorObra.innerHTML = obraNova.autor;
      txtDescObra.innerHTML = obraNova.sinopse;
      txtEditObra.innerHTML += obraNova.editora;
      txtPagsObra.innerHTML += obraNova.paginas;
      txtI13Obra.innerHTML += obraNova.isbn13;
      imgObra.src = obraNova.imagem;
      gIsbn = obraNova.isbn13;
  }



  const estante = await getDocs(query(collection(doc(banco, "usuarios", usuario), "estante"), where("ISBN", "==", isbn)));
  if(!estante.empty) {
      if (estante.docs[0].data().categoria == 'B') {
          botaoCoracao.classList.add('desativado')
          botaoLivro.classList.remove('mdi-book-open-outline')
          botaoLivro.classList.add('mdi-book-open')
      } else if (estante.docs[0].data().categoria == 'A') {
          botaoLivro.classList.add('desativado')
          botaoCoracao.classList.remove('mdi-heart-outline')
          botaoCoracao.classList.add('mdi-heart')
      }
  }

  txtQuantia.innerHTML = quantia.docs.length + " disponíveis para trocar";

  
};

await carregaPag();
document.querySelectorAll('img').forEach(img => {
  if (img.src.startsWith('http://')) {
    img.src = img.src.replace("http://", "https://");
  }
});



btnTrocar.addEventListener("click", () => {
  window.location.href = `trocasdisponiveis.html?isbn=${gIsbn}`;
});

btnCadastrar.addEventListener("click", () => {
  window.location.href = `cadastrarlivro.html?isbn=${gIsbn}`;
});




botaoCoracao.addEventListener("click", async function () {
  const isbn = localStorage.getItem("obraSelecionada");
  const estanteRef = doc(collection(doc(banco, "usuarios", usuario), "estante"), isbn);

  this.classList.add('desativado')
  const isAtivo = botaoCoracao.classList.contains("mdi-heart");

  try {
      if (isAtivo) {
          await deleteDoc(estanteRef);
          this.classList.remove('desativado', 'mdi-heart');
          this.classList.add('mdi-heart-outline')
          botaoLivro.classList.remove('desativado')
      } else {
          botaoLivro.classList.add('desativado')
          await setDoc(estanteRef, {
              ISBN: isbn,
              categoria: "A",
          });
          this.classList.remove('mdi-heart-outline')
          this.classList.add("mdi-heart");
      }
  } catch (error) {
      console.error("Erro ao atualizar estante:", error);
      alert("Ocorreu um erro. Tente novamente.");
  } finally {
    this.classList.remove('desativado')
  }
});

botaoLivro.addEventListener("click", async function () {
  const isbn = localStorage.getItem("obraSelecionada");
  const estanteRef = doc(collection(doc(banco, "usuarios", usuario), "estante"), isbn);

  this.classList.add('desativado')
  const isAtivo = this.classList.contains("mdi-book-open");

  try {
      if (isAtivo) {
          await deleteDoc(estanteRef);
          this.classList.remove('desativado', 'mdi-book-open');
          this.classList.add('mdi-book-open-outline')
          botaoCoracao.classList.remove('desativado')
      } else {
          botaoCoracao.classList.add('desativado')
          await setDoc(estanteRef, {
              ISBN: isbn,
              categoria: "B",
          });
          this.classList.remove('mdi-book-open-outline')
          this.classList.add("mdi-book-open");
      }
  } catch (error) {
      console.error("Erro ao atualizar estante:", error);
      alert("Ocorreu um erro. Tente novamente.");
  } finally {
    this.classList.remove('desativado')
  }
});


}, false);


