import {banco, verificador} from "./firebase/configuracao.js";
import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";


const swiper = new Swiper('.swiper-container', {
  slidesPerView: 1,
  spaceBetween: 20,
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  },
  breakpoints: {
    768: {
      slidesPerView: 2,
    },
    1024: {
      slidesPerView: 3,
    },
  },
});

document.addEventListener('deviceready', async function () {


  onAuthStateChanged(verificador, (user) => {
    if (user) {
      console.log("Usuário logado:", user.email);
    } else {
      console.log("Nenhum usuário logado");
      window.location.href = "login.html";
    }
  });

const btnInit = document.getElementById("btnInit");



const imgUsuario = document.getElementById("imgUsuario");
const imgMain = document.getElementById("main-image");
const txtTitulo = document.getElementById("txtTitulo");
const txtUsuario = document.getElementById("txtUsuario");
const txtDesc = document.getElementById("txtDesc");
const txtEstado = document.getElementById("txtEstado");
const txtCidade = document.getElementById("txtCidade");

const pegaObra = async() => {
  const urlPesquisa = new URLSearchParams(window.location.search);
  return urlPesquisa.get("id");
}

const pesquisaInfo = async (isbn) => {
  const livro = await buscaLivroISBN(isbn);
  const titulo = livro.titulo;

  return titulo;
}

const carregaPag = async () => {

    const idObra = await pegaObra();

    const resultado = await getDoc(doc(banco, "Obra", idObra));
    const titulo = await pesquisaInfo(resultado.data().ISBN);
    imgMain.src = resultado.data().foto_obra[0];
    txtEstado.textContent = resultado.data().estado_obra;

    

    const dono = resultado.data().id_usu

    const usu1 = await getDoc(doc(banco, "usuarios", dono));
    const usu2 = await getDoc(doc(banco, "usuarios", dono, "perfil", "dados"));

    btnInit.addEventListener("click", () => {
      window.location.href = `https://alexandriatcc.netlify.app/pages/chat.html?init=${dono}`;
    });
    
    txtTitulo.innerHTML = titulo;
    txtDesc.innerHTML = resultado.data().descricao_obra;
    txtUsuario.innerHTML = usu1.data().nome_usu;
    txtCidade.innerHTML = usu1.data().cidade_usu;
    imgUsuario.src = usu2.data().foto_usu;

}

carregaPag();
}, false);

