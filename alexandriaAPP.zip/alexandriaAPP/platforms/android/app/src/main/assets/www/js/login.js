import {banco, verificador} from "./firebase/configuracao.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification, sendPasswordResetEmail}
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

document.addEventListener('deviceready', async function () {
    document.getElementById("formLogin").addEventListener("submit", async (event) => {
        event.preventDefault();
    
        const email = document.getElementById("email-login").value;
        const senha = document.getElementById("password").value;
    
        try {
            const usuAut = await signInWithEmailAndPassword(verificador, email, senha);
    
            if (usuAut.user.emailVerified) {
                window.location.href = "index.html";
            } else {
                alert("Por favor, verifique seu email antes de acessar.");
            }
        } catch (e) {
            if (e.message == "Firebase: Error (auth/invalid-login-credentials).") {
                alert("Email e/ou Senha inválidos.")
            } else {
                alert("Erro ao realizar login: " + e.message);
            }
        }
    });
});