  function openPopup() {
    document.getElementById('popup').style.display = 'flex';
  }

  function closePopup(event) {
    if (event.target.id === 'popup') {
      document.getElementById('popup').style.display = 'none';
    }
  }

document.addEventListener('DOMContentLoaded', function () {
  const swiper = new Swiper('.swiper-container', {
    slidesPerView: 2.5,
    spaceBetween: 1,
    breakpoints: {
      768: { slidesPerView: 2 },
      1024: { slidesPerView: 3 },
    },
  });
});
