import {banco, verificador} from "./firebase/configuracao.js";
import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification, sendPasswordResetEmail}
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

document.addEventListener('deviceready', async function () {

  const imgPerfil = document.getElementById("imgPerfil");
  const txtNome = document.getElementById("txtNome");
  const txtNivel = document.getElementById("txtNivel");
  
  
  let usuario;
  
  const verificaUsuario = async () => {
      return new Promise((resolve, reject) => {
        onAuthStateChanged(verificador, (user) => {
          if (user) {
            console.log("Usuário logado:", user.email);
            usuario = user.uid;
            resolve(usuario);
          } else {
            console.log("Nenhum usuário logado");
            window.location.href = "login.html";
            reject("Usuário não logado");
          }
        });
      });
  };
  
  const abreLivro = (livro) => {
      window.location.href = `livrodono2.html?id=${livro}`;
  }
  
  const criaLivro = async (livro) => {
      console.log(livro);
      const info = await pesquisaInfo(livro.ISBN);
  
      return `<div class="swiper-slide"> <div class="card3 cor-link">
                    <div class="card-image-container3">
                      <img src="${livro.foto_obra[0]}" alt="Imagem do Card" class="card-image3">
                    </div>
                    <div class="card-content3">
                      <h3 class="card-title3">${info[0]}</h3>
                      <p class="card-subtitle3">Estado: ${livro.estado_obra}</p>
                    </div>
                  </div></div>`;
  }
  
  const criaCompra = async (compra) => { 
      const tabela = document.getElementById("tabelaCompras");
      const datado = new Date(compra.data_hora.seconds * 1000)
  
      const dia = String(datado.getDate()).padStart(2, '0');
      const mes = String(datado.getMonth() + 1).padStart(2, '0');
      const ano = datado.getFullYear();
  
      const formadatado = `${dia}/${mes}/${ano}`;
  
      tabela.innerHTML += `
      <tr>
        <td>${formadatado}</td>
        <td>Leitor Nível ${compra.nivel_moeda}</td>
        <td>${compra.valor_moeda}</td>
      </tr>`
  }
  
  const criaTroca = async (troca) => {
      let outroUsu;
      if (troca.id_remetente == usuario) {
          outroUsu = troca.id_destinatario
      } else if (troca.id_destinatario == usuario) {
          outroUsu = troca.id_remetente
      }
  
      const info2 = await pesquisaInfo2(troca.id_obra);
      const info3 = await pesquisaInfo3(outroUsu);
  
const container2 = document.getElementById("containerTrocas");
      container2.innerHTML = `
      
      <div class="card-horizontal">
              <img class="card-image-large" src="${info2[0]}" alt="img">
              <div class="card-content">
                <div class="card-header">
                  <img class="card-image-small" src="${info3[1]}" alt="img">
                  <h2 class="card-title">${info3[0]}</h2>
                </div>
                <p class="card-subtitle">Estado do Livro: ${info2[1]}</p>
              </div>
            </div>`;
  
  
  }
  
  const pesquisaPerfil = async (dono) => {
      const resultado1 = await getDoc(doc(banco, "usuarios", dono));
      const resultado2 = await getDoc(doc(banco, "usuarios", dono, "perfil", "dados"));
      const perfil = [];
      if (resultado1.exists() && resultado2.exists()) {
          perfil.push({...resultado1.data(), ...resultado2.data()});
      } else {
          console.log("Dados não encontrados.");
      }
      return perfil[0];
  }
  
  const pesquisaLivros = async (dono) => {
      const resultado = await getDocs(query(collection(banco, "Obra"), where("id_usu", "==", dono), where("trocado", "==", false)));
  
      if (resultado.empty) {
          console.log("Sem livros")
          return '';
      } else {
          const livros = [];
          resultado.forEach(doc => {
            livros.push({id_obra: doc.id, ...doc.data()});
          });
          return livros;
      }
  }
  
  const pesquisaTrocas = async (dono) => {
      const resultado = await getDocs(query(collection(banco, "troca"), where("id_remetente", "==", dono)));
      const resultado2 = await getDocs(query(collection(banco, "troca"), where("id_destinatario", "==", dono)));
  
      
  
      if (resultado.empty) {
          console.log("Sem trocas")
          return '';
      } else {
          const trocas = [
              ...resultado.docs.map(doc => ({ id: doc.id, ...doc.data() })),
              ...resultado2.docs.map(doc => ({ id: doc.id, ...doc.data() }))
          ];
          return trocas;
      }
  }
  
  const pesquisaInfo = async (isbn) => {
      const livro = await buscaLivroISBN(isbn);
      const titulo = livro.titulo;
      const autor = livro.autor
    
      return [titulo, autor];
  }
  
  const pesquisaInfo2 = async (trocada) => {
      const resultado = await getDoc(doc(banco, "Obra", trocada))
      return [resultado.data().foto_obra[0], resultado.data().estado_obra]
  }
  
  const pesquisaInfo3 = async (cara) => {
      const resultado1 = await getDoc(doc(banco, "usuarios", cara));
      const resultado2 = await getDoc(doc(banco, "usuarios", cara, "perfil", "dados"));
  
      return [resultado1.data().nome_usu, resultado2.data().foto_usu];
  }
  
  
  const carregaPag = async () => {
      await verificaUsuario();
      const perfil = await pesquisaPerfil(usuario);
  
      imgPerfil.src = perfil.foto_usu;
      txtNome.innerHTML = perfil.nome_usu;

      txtNivel.innerHTML = "Nível " + perfil.nivel_usu;
  
      
  
      const container = document.getElementById("containerMeusLivros");
  
      try {
          const livros = await pesquisaLivros(usuario);
  
  
          if (livros.length > 0) {
          const cardsLivro = await Promise.all(livros.map(criaLivro));
          container.innerHTML = cardsLivro.join("");
          } else {
          container.innerHTML = "<p>Nenhum livro encontrado.</p>";
          }
  
          container.querySelectorAll(".swiper-slide").forEach((botao, index) => {
          botao.addEventListener("click", () => abreLivro(livros[index].id_obra));
          });
      } catch (e) {
          console.log(e);
          container.innerHTML = "<p>Erro ao carregar livros. Tente novamente mais tarde.</p>";
      }
  
      const container2 = document.getElementById("containerTrocas");
      container2.innerHTML = "<p>Carregando Trocas...</p>"
  
      try {
          const trocas = await pesquisaTrocas(usuario);
  
          if (trocas.length > 0) {
              const cardsTroca = await Promise.all(trocas.map(criaTroca));
          } else {
              container2.innerHTML = "<p>Nenhuma troca encontrada.</p>"
          }
      }catch (e) {
          console.log(e);
          container2.innerHTML = "<p>Erro ao carregar trocas. Tente novamente mais tarde.</p>";
      }
  
      try {
          const compras = await getDocs(query(collection(banco, "Historico_Compras"), where("id_usu", "==", usuario)));
          console.log(compras)
  
          if (compras.docs.length > 0) {
              console.log(compras.docs)
              compras.docs.forEach(doc => {
                  criaCompra(doc.data());
              })
          } else {
              console.log("menos")
          }
      } catch (e) {
          console.log(e);
      }
  }
  
  await carregaPag();

  document.getElementById("btnSair").addEventListener("click", () => {
    const confirmar = confirm("Você tem certeza que deseja sair da conta?");
        if (confirmar) {
            alert("Você saiu da conta.");
            signOut(verificador);
        } else {
            console.log("O usuário decidiu não sair.");
        }
  })

}, false);

