import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import {banco, verificador} from "./firebase/configuracao.js";
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

document.addEventListener('deviceready', async function () {

    onAuthStateChanged(verificador, (user) => {
        if (user) {
          console.log("Usuário logado:", user.email);
        } else {
          console.log("Nenhum usuário logado");
          window.location.href = "login.html";
        }
      });

      const pegaPesquisa = async() => {
        const urlPesquisa = new URLSearchParams(window.location.search);
        if (!urlPesquisa.get("q")) {
          return "Romance";
        } else {
        return urlPesquisa.get("q");
        }
      }
      
      /*

      */
      
      const tituloPesquisa = document.getElementById("tituloPesquisa");
    

      const abrirObra = (obra, titulo, autor) => {
        localStorage.setItem("obraSelecionada", obra);
        localStorage.setItem("obraTitulo", titulo);
        window.location.href = "livro.html";
      };
      
      const abrirCadastro = (obra) => {
        window.location.href = `cadastro_livro.html?isbn=${obra}`;
      };
      
      
      const criarObra = (livro) => {
        return `
        <div class="card3 cor-link" info-isbn="${livro.isbn13}" info-titulo="${livro.titulo}">
        <img src="${livro.imagem}" alt="Imagem do Card" class="card-image3">
        <div class="card-content3">
            <h3 class="card-title3">${livro.titulo}</h3>
            <p class="card-subtitle3">por ${livro.autor}</p>
        </div>
        </div>
        `;
      };
      
      
      const carregarObras = async (pesquisa, containerId, inicio) => {
        const container = document.getElementById(containerId);
        container.innerHTML = "<p>Carregando Livros...</p>";
      
        try {
          const obras = await buscaLivroTexto(pesquisa, inicio);
      
          if (obras.length > 0) {
            container.innerHTML = obras.map(criarObra).join("");
          } else {
            container.innerHTML = "<p>Nenhum livro encontrado.</p>";
          }
          
          container.querySelectorAll(".card3").forEach((botao) => {
            const isbn = botao.getAttribute("info-isbn");
            const titulo = botao.getAttribute("info-titulo");
      
            botao.addEventListener("click", () => abrirObra(isbn, titulo));
          });
      
      
        } catch (e) {
          container.innerHTML = "<p>Erro ao carregar livros. Tente novamente mais tarde.</p>";
        }
      };



    var pesquisa = '';
    await pegaPesquisa().then((valor) => {
      pesquisa = valor;
    });

    tituloPesquisa.innerHTML = pesquisa;
    await carregarObras(pesquisa, "resultado", 0); 

    document.querySelectorAll('img').forEach(img => {
        if (img.src.startsWith('http://')) {
          img.src = img.src.replace("http://", "https://");
        }
      });
}, false);

