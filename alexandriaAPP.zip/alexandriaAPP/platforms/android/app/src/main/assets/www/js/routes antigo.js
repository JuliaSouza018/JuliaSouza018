//INICIALIZAÇÃO DO F7 QUANDO DISPOSITIVO ESTÁ PRONTO
document.addEventListener("deviceready", onDeviceReady, false);
var app = new Framework7({
  // App root element
  el: "#app",
  // App Name
  name: "My App",
  // App id
  id: "com.myapp.test",
  // Enable swipe panel
  panel: {
    swipe: true,
  },
  dialog: {
    buttonOk: "Sim",
    buttonCancel: "Cancelar",
  },
  // Add default routes
  routes: [
    {
      path: "/index/",
      url: "index.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          $("#menuPrincipal").show("fast");

          const swiper = new Swiper(".swiper-container", {
            slidesPerView: 2,
            spaceBetween: 10,
            freeMode: true,
          });
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/index.css" type="text/css" />');

          $.getScript("js/index.js");

        },
        pageBeforeRemove: function (event, page) {
          $("#css-index").remove();
        },
      },
    },
    {
      path: "/estante/",
      url: "estante.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          // fazer algo antes da página ser exibida
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/estante.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-estante").remove();
        },
      },
    },
    {
      path: "/listachat/",
      url: "listachat.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          $("#menuPrincipal").show("fast");
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/listachat.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-listachat").remove();
        },
      },
    },
    {
      path: "/perfil/",
      url: "perfil.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          const swiper = new Swiper(".swiper-container", {
            slidesPerView: 2,
            spaceBetween: 10,
            freeMode: true,
          });
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/perfil.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-perfil").remove();
        },
      },
    },
    {
      path: "/livro/",
      url: "livro.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          const swiper = new Swiper(".table-swiper", {
            slidesPerView: 1,
            spaceBetween: 10,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
          });
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/livro.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-livro").remove();
        },
      },
    },
    {
      path: "/detalhes/",
      url: "detalhes.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          $("#menu-principal").hide("fast");
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/detalhes.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-detalhes").remove();
        },
      },
    },
    {
      path: "/livroslidos/",
      url: "livroslidos.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/livroslidos.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-livroslidos").remove();
        },
      },
    },
    {
      path: "/listadedesejos/",
      url: "listadedesejos.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/listadedesejos.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-listadedesejos").remove();
        },
      },
    },
    {
      path: "/meuslivros/",
      url: "meuslivros.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/meuslivros.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-meuslivros").remove();
        },
      },
    },
    {
      path: "/cadastrarlivro/",
      url: "cadastrarlivro.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/cadastrarlivro.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-cadastrarlivro").remove();
        },
      },
    },
    {
      path: "/pesquisar/",
      url: "pesquisar.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          $("#menuPrincipal").hide("fast");
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/pesquisar.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-pesquisar").remove();
        },
      },
    },
    {
      path: "/chat/",
      url: "chat.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          $("#menuPrincipal").hide("fast");
         
        
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/chat.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-chat").remove();
        },
      },
    },
    {
      path: "/recomendados/",
      url: "recomendados.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/recomendados.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-recomendados").remove();
        },
      },
    },
    {
      path: "/novos/",
      url: "novos.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/novos.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-novos").remove();
        },
      },
    },
    {
      path: "/ultimas/",
      url: "ultimas.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/ultimas.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-ultimas").remove();
        },
      },
    },
    {
      path: "/kids/",
      url: "kids.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/kids.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-kids").remove();
        },
      },
    },
    {
      path: "/ficcao/",
      url: "ficcao.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/ficcao.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-ficcao").remove();
        },
      },
    },
    {
      path: "/romance/",
      url: "romance.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/romance.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-romance").remove();
        },
      },
    },
    {
      path: "/todos/",
      url: "todos.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/todos.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-todos").remove();
        },
      },
    },
    {
      path: "/trocasdisponiveis/",
      url: "trocasdisponiveis.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/trocasdisponiveis.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-trocasdisponiveis").remove();
        },
      },
    },
    {
      path: "/chat/",
      url: "chat.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          
        },
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/chat.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-chat").remove();
        },
      },
    },
    {
      path: "/cadastrar/",
      url: "cadastrar.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/cadastrar.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-cadastrar").remove();
        },
      },
    },
    {
      path: "/login/",
      url: "login.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/login.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-login").remove();
        },
      },
    },
    {
      path: "/login2/",
      url: "login2.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/login2.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-login2").remove();
        },
      },
    },
    {
      path: "/recuperarsenha/",
      url: "recuperarsenha.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/recuperarsenha.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-recuperarsenha").remove();
        },
      },
    },
    {
      path: "/confirmaremail/",
      url: "confirmaremail.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/confirmaremail.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-confirmaremail").remove();
        },
      },
    },
    {
      path: "/manterlogin/",
      url: "manterlogin.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
          // fazer algo depois da página ser exibida
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/manterlogin.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-manterlogin").remove();
        },
      },
    },
    {
      path: "/trocasrecentes/",
      url: "trocasrecentes.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/trocasrecentes.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-trocasrecentes").remove();
        },
      },
    },
    {
      path: "/editar/",
      url: "editar.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {},
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/editar.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-editar").remove();
        },
      },
    },
    
    {
      path: "/compramoeda/",
      url: "compramoeda.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {

          const slider = document.querySelector('.slider');
    const dots = document.querySelectorAll('.dot');
    let currentIndex = 0;
    
    // Atualizar Slider
    function updateSlider(index) {
      slider.style.transform = `translateX(-${index * 100}%)`;
      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
      });
    }
    
    // Navegar pelos Dots
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        currentIndex = index;
        updateSlider(index);
      });
    });

        },
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/compramoeda.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-compramoeda").remove();
        },
      },
    },
    {
      path: "/quantiamoeda/",
      url: "quantiamoeda.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          
          
    document.addEventListener("DOMContentLoaded", () => {
      const counterNumber = document.getElementById("counter");
      const buttonPlus = document.getElementById("increase");
      const buttonMinus = document.getElementById("decrease");
    
      let counterValue = 1;
    
      // Adiciona eventos aos botões
      buttonPlus.addEventListener("click", () => {
        counterValue++;
        counterNumber.textContent = counterValue;
      });
    
      buttonMinus.addEventListener("click", () => {
        if (counterValue > 0) {
          counterValue--;
          counterNumber.textContent = counterValue;
        }
      });
    });



        },
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/quantiamoeda.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-quantiamoeda").remove();
        },
      },
    },
    {
      path: "/formapagar/",
      url: "formapagar.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          
        },
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/formapagar.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-formapagar").remove();
        },
      },
    },
    {
      path: "/resumocompra/",
      url: "resumocompra.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          
        },
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/resumocompra.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-resumocompra").remove();
        },
      },
    },
    {
      path: "/livrodono/",
      url: "livrodono.html",
      animate: false,
      on: {
        pageBeforeIn: function (event, page) {
          
        },
        pageAfterIn: function (event, page) {
        },
        pageInit: function (event, page) {
          $("head").append(
            '<link rel="stylesheet" href="css/livrodono.css" type="text/css" />'
          );
        },
        pageBeforeRemove: function (event, page) {
          $("#css-livrodono").remove();
        },
      },
    },
  ],
  // ... other parameters
});

//Para testes direto no navegador
var mainView = app.views.create(".view-main", { url: "/index/" });

//EVENTO PARA SABER O ITEM DO MENU ATUAL
app.on("routeChange", function (route) {
  var currentRoute = route.url;
  console.log(currentRoute);
  document.querySelectorAll(".tab-link").forEach(function (el) {
    el.classList.remove("active");
  });
  var targetEl = document.querySelector(
    '.tab-link[href="' + currentRoute + '"]'
  );
  if (targetEl) {
    targetEl.classList.add("active");
  }
});

function onDeviceReady() {
  //Quando estiver rodando no celular
  var mainView = app.views.create(".view-main", { url: "/index/" });

  //COMANDO PARA "OUVIR" O BOTAO VOLTAR NATIVO DO ANDROID
  document.addEventListener(
    "backbutton",
    function (e) {
      if (mainView.router.currentRoute.path === "/index/") {
        e.preventDefault();
        app.dialog.confirm("Deseja sair do aplicativo?", function () {
          navigator.app.exitApp();
        });
      } else {
        e.preventDefault();
        mainView.router.back({ force: true });
      }
    },
    false
  );
}
