//INICIALIZAÇÃO DO F7 QUANDO DISPOSITIVO ESTÁ PRONTO
document.addEventListener("deviceready", onDeviceReady, false);
var app = new Framework7({
  // App root element
  el: "#app",
  // App Name

});

//Para testes direto no navegador

//EVENTO PARA SABER O ITEM DO MENU ATUAL


function onDeviceReady() {
  //Quando estiver rodando no celular

}
