import {banco, verificador} from "./firebase/configuracao.js";
import {buscaLivroISBN, buscaLivroTexto} from "./firebase/configLivro.js"; 
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDoc, getDocs, where, query }
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification, sendPasswordResetEmail}
from "https://www.gstatic.com/firebasejs/9.0.0/firebase-auth.js";

document.addEventListener('deviceready', async function () {
/*
            
*/
  let usuario;
  
  const verificaUsuario = async () => {
      return new Promise((resolve, reject) => {
        onAuthStateChanged(verificador, (user) => {
          if (user) {
            console.log("Usuário logado:", user.email);
            usuario = user.uid;
            resolve(usuario);
          } else {
            console.log("Nenhum usuário logado");
            window.location.href = "login.html";
            reject("Usuário não logado");
          }
        });
      });
  };
  
 

  
  const criaTroca = async (troca) => {
      let outroUsu;
      if (troca.id_remetente == usuario) {
          outroUsu = troca.id_destinatario
      } else if (troca.id_destinatario == usuario) {
          outroUsu = troca.id_remetente
      }
  
      const info2 = await pesquisaInfo2(troca.id_obra);
      const info3 = await pesquisaInfo3(outroUsu);
  
      return `<div class="card-container3">
                <div class="card-horizontal">
                  <img class="card-image-large" src="${info2[0]}" alt="img">
                  <div class="card-content">
                    <h2 class="card-title">${info3[0]}</h2>
                    <p class="card-subtitle">Estado do Livro: ${info2[1]}</p>
                  </div>
                </div>
              </div>`;
  
  
  }
  
  
  
  const pesquisaTrocas = async (dono) => {
      const resultado = await getDocs(query(collection(banco, "troca"), where("id_remetente", "==", dono)));
      const resultado2 = await getDocs(query(collection(banco, "troca"), where("id_destinatario", "==", dono)));
  
      
  
      if (resultado.empty) {
          console.log("Sem trocas")
          return '';
      } else {
          const trocas = [
              ...resultado.docs.map(doc => ({ id: doc.id, ...doc.data() })),
              ...resultado2.docs.map(doc => ({ id: doc.id, ...doc.data() }))
          ];
          return trocas;
      }
  }
  
  
  const pesquisaInfo2 = async (trocada) => {
      const resultado = await getDoc(doc(banco, "Obra", trocada))
      return [resultado.data().foto_obra[0], resultado.data().estado_obra]
  }
  
  const pesquisaInfo3 = async (cara) => {
      const resultado1 = await getDoc(doc(banco, "usuarios", cara));
      const resultado2 = await getDoc(doc(banco, "usuarios", cara, "perfil", "dados"));
  
      return [resultado1.data().nome_usu, resultado2.data().foto_usu];
  }
  
  
  const carregaPag = async () => {
      await verificaUsuario(); 
      
  
      const container2 = document.getElementById("containerTrocas");
      container2.innerHTML = "<p>Carregando Trocas...</p>"
  
      try {
          const trocas = await pesquisaTrocas(usuario);
  
          if (trocas.length > 0) {
              const cardsTroca = await Promise.all(trocas.map(criaTroca));
              container2.innerHTML = cardsTroca.join("");
          } else {
              container2.innerHTML = "<p>Nenhuma troca encontrada.</p>"
          }
      }catch (e) {
          console.log(e);
          container2.innerHTML = "<p>Erro ao carregar trocas. Tente novamente mais tarde.</p>";
      }
  }
  
  await carregaPag();

}, false);

